# Cyberpunk Theme for GRUB Bootloader
A GRUB Bootloader Theme Inspired by Cyberpunk 2077.
Thanks to @anoopmsivadas for making this theme. I've given it a new look.
![Preview](Screenshots/screenshot.png)

## Install

```shell
git clone https://github.com/NayamAmarshe/Cyberpunk-GRUB-Theme.git && cd Cyberp*
sudo ./install.sh
```
![Preview](Screenshots/screenshot0.png)

NOTE: Tested on 1920x1080 resolution.

### Available on pling : [https://www.pling.com/p/1515662/](https://www.pling.com/p/1515662/)
